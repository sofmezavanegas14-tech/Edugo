const express = require("express");
const cors = require("cors");
const path = require("path");
const dotenv = require("dotenv");
const OpenAI = require("openai");

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT || 3000);
const MODEL = process.env.OPENAI_MODEL || "gpt-5.6-luna";

if (!process.env.OPENAI_API_KEY) {
  console.warn("⚠️ OPENAI_API_KEY no está configurada. El servidor arrancará, pero la IA no responderá.");
}

const openai = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

app.use(cors());
app.use(express.json({ limit: "32kb" }));
app.use(express.static(path.join(__dirname, "..")));

const requestLog = new Map();
const WINDOW_MS = 60_000;
const MAX_REQUESTS_PER_WINDOW = 12;

function rateLimit(ip) {
  const now = Date.now();
  const entry = requestLog.get(ip) || { start: now, count: 0 };
  if (now - entry.start >= WINDOW_MS) {
    entry.start = now;
    entry.count = 0;
  }
  entry.count += 1;
  requestLog.set(ip, entry);
  return entry.count <= MAX_REQUESTS_PER_WINDOW;
}

app.get("/api/health", (req, res) => {
  res.json({ ok: true, aiConfigured: Boolean(openai), model: MODEL });
});

app.post("/api/edugo-ai", async (req, res) => {
  try {
    if (!rateLimit(req.ip)) {
      return res.status(429).json({ error: "Has enviado muchas preguntas. Espera un momento e inténtalo de nuevo." });
    }

    const question = typeof req.body?.question === "string" ? req.body.question.trim() : "";

    if (!question) {
      return res.status(400).json({ error: "Escribe una pregunta." });
    }

    if (question.length > 4000) {
      return res.status(400).json({ error: "La pregunta es demasiado larga. Usa hasta 4000 caracteres." });
    }

    if (!openai) {
      return res.status(503).json({ error: "La IA todavía no está configurada en el servidor. Añade OPENAI_API_KEY en las variables de entorno." });
    }

    const response = await openai.responses.create({
      model: MODEL,
      instructions: `Eres Asistente EduGo, una IA educativa para estudiantes.\n\n- Responde en español salvo que el estudiante pida otro idioma.\n- Explica con palabras claras y apropiadas para estudiantes.\n- En ejercicios, muestra el procedimiento paso a paso y luego la respuesta.\n- Ayuda con matemáticas, ciencias, español, sociales, inglés, tecnología y otras materias escolares.\n- Si una pregunta es ambigua, pide el dato mínimo necesario.\n- No inventes fuentes, datos ni resultados.\n- No solicites datos personales innecesarios.\n- Mantén el contenido educativo y apropiado para menores.`,
      input: question,
      max_output_tokens: 900
    });

    const answer = response.output_text?.trim();
    if (!answer) {
      return res.status(502).json({ error: "La IA no devolvió una respuesta." });
    }

    res.json({ ok: true, answer });
  } catch (error) {
    console.error("EduGo IA error:", error?.message || error);
    res.status(500).json({ error: "No fue posible conectar con el Asistente EduGo. Inténtalo nuevamente." });
  }
});

app.listen(PORT, () => {
  console.log(`EduGo listo en http://localhost:${PORT}`);
  console.log(`Modelo configurado: ${MODEL}`);
});
